const { add, subtract, multiply, divide } = require("/app/src/utils");

describe("Basic Math Operations", () => {
  describe("add", () => {
    test("adds positive numbers", () => {
      expect(add(2, 3)).toBe(5);
      expect(add(10, 25)).toBe(35);
    });

    test("adds negative numbers", () => {
      expect(add(-5, -3)).toBe(-8);
      expect(add(-10, -20)).toBe(-30);
    });

    test("adds mixed positive and negative", () => {
      expect(add(10, -5)).toBe(5);
      expect(add(-15, 25)).toBe(10);
    });

    test("adds with zero", () => {
      expect(add(0, 0)).toBe(0);
      expect(add(5, 0)).toBe(5);
      expect(add(0, -3)).toBe(-3);
    });
  });

  describe("subtract", () => {
    test("subtracts positive numbers", () => {
      expect(subtract(10, 3)).toBe(7);
      expect(subtract(100, 50)).toBe(50);
    });

    test("subtracts negative numbers", () => {
      expect(subtract(-5, -3)).toBe(-2);
      expect(subtract(-10, -20)).toBe(10);
    });

    test("subtracts with zero", () => {
      expect(subtract(10, 0)).toBe(10);
      expect(subtract(0, 5)).toBe(-5);
    });
  });

  describe("multiply", () => {
    test("multiplies positive numbers", () => {
      expect(multiply(4, 5)).toBe(20);
      expect(multiply(7, 8)).toBe(56);
    });

    test("multiplies with zero", () => {
      expect(multiply(5, 0)).toBe(0);
      expect(multiply(0, 10)).toBe(0);
      expect(multiply(0, 0)).toBe(0);
    });

    test("multiplies negative numbers", () => {
      expect(multiply(-3, 4)).toBe(-12);
      expect(multiply(-5, -6)).toBe(30);
      expect(multiply(7, -2)).toBe(-14);
    });
  });

  describe("divide", () => {
    test("divides positive numbers", () => {
      expect(divide(10, 2)).toBe(5);
      expect(divide(100, 4)).toBe(25);
    });

    test("divides with decimals", () => {
      expect(divide(7, 2)).toBe(3.5);
      expect(divide(5, 4)).toBe(1.25);
    });

    test("divides negative numbers", () => {
      expect(divide(-10, 2)).toBe(-5);
      expect(divide(10, -5)).toBe(-2);
      expect(divide(-20, -4)).toBe(5);
    });

    test("throws error on division by zero", () => {
      expect(() => divide(5, 0)).toThrow();
      expect(() => divide(0, 0)).toThrow();
      expect(() => divide(-10, 0)).toThrow();
    });
  });
});
