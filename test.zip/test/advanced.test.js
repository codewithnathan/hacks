const { isPrime, fibonacci } = require("/app/src/utils");

describe("Advanced Functions", () => {
  describe("isPrime", () => {
    test("identifies small primes", () => {
      expect(isPrime(2)).toBe(true);
      expect(isPrime(3)).toBe(true);
      expect(isPrime(5)).toBe(true);
      expect(isPrime(7)).toBe(true);
      expect(isPrime(11)).toBe(true);
      expect(isPrime(13)).toBe(true);
    });

    test("identifies larger primes", () => {
      expect(isPrime(17)).toBe(true);
      expect(isPrime(19)).toBe(true);
      expect(isPrime(23)).toBe(true);
      expect(isPrime(29)).toBe(true);
      expect(isPrime(97)).toBe(true);
    });

    test("identifies non-primes", () => {
      expect(isPrime(4)).toBe(false);
      expect(isPrime(6)).toBe(false);
      expect(isPrime(8)).toBe(false);
      expect(isPrime(9)).toBe(false);
      expect(isPrime(10)).toBe(false);
      expect(isPrime(15)).toBe(false);
      expect(isPrime(20)).toBe(false);
      expect(isPrime(100)).toBe(false);
    });

    test("handles edge cases", () => {
      expect(isPrime(0)).toBe(false);
      expect(isPrime(1)).toBe(false);
      expect(isPrime(-5)).toBe(false);
      expect(isPrime(-17)).toBe(false);
    });
  });

  describe("fibonacci", () => {
    test("calculates base cases", () => {
      expect(fibonacci(0)).toBe(0);
      expect(fibonacci(1)).toBe(1);
    });

    test("calculates small fibonacci numbers", () => {
      expect(fibonacci(2)).toBe(1);
      expect(fibonacci(3)).toBe(2);
      expect(fibonacci(4)).toBe(3);
      expect(fibonacci(5)).toBe(5);
      expect(fibonacci(6)).toBe(8);
      expect(fibonacci(7)).toBe(13);
    });

    test("calculates larger fibonacci numbers", () => {
      expect(fibonacci(10)).toBe(55);
      expect(fibonacci(15)).toBe(610);
      expect(fibonacci(20)).toBe(6765);
    });

    test("handles negative input", () => {
      expect(fibonacci(-1)).toBe(0);
      expect(fibonacci(-5)).toBe(0);
    });
  });
});
