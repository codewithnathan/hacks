const utils = require("/app/src/utils");

describe("Integration Tests", () => {
  test("all functions are exported", () => {
    expect(typeof utils.add).toBe("function");
    expect(typeof utils.subtract).toBe("function");
    expect(typeof utils.multiply).toBe("function");
    expect(typeof utils.divide).toBe("function");
    expect(typeof utils.isPrime).toBe("function");
    expect(typeof utils.fibonacci).toBe("function");
  });

  test("complex calculation", () => {
    // (10 + 5) * 2 - 3 = 27
    const step1 = utils.add(10, 5);
    const step2 = utils.multiply(step1, 2);
    const step3 = utils.subtract(step2, 3);
    expect(step3).toBe(27);
  });

  test("fibonacci with prime check", () => {
    const fib5 = utils.fibonacci(5); // 5
    expect(fib5).toBe(5);
    expect(utils.isPrime(fib5)).toBe(true);

    const fib7 = utils.fibonacci(7); // 13
    expect(fib7).toBe(13);
    expect(utils.isPrime(fib7)).toBe(true);

    const fib6 = utils.fibonacci(6); // 8
    expect(fib6).toBe(8);
    expect(utils.isPrime(fib6)).toBe(false);
  });

  test("division with validation", () => {
    const result = utils.divide(100, 4);
    expect(result).toBe(25);
    expect(utils.isPrime(result)).toBe(false);
  });

  test("all operations work together", () => {
    expect(utils.add(1, 1)).toBe(2);
    expect(utils.subtract(10, 5)).toBe(5);
    expect(utils.multiply(3, 4)).toBe(12);
    expect(utils.divide(20, 4)).toBe(5);
    expect(utils.isPrime(7)).toBe(true);
    expect(utils.fibonacci(10)).toBe(55);
  });
});
